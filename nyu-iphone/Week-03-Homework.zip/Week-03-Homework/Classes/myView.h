//
//  myView.h
//  Week-03-Homework
//
//  Created by Michael Fenimore on 6/25/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface myView : UIView {

}

@end
