//
//  main.m
//  Week-03-Homework
//
//  Created by Michael Fenimore on 6/25/11.
//  Copyright 2011 __MichaelFenmore__. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, @"Week_03_HomeworkAppDelegate");
    [pool release];
    return retVal;
}
