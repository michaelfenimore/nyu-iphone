//
//  LittleView2.h
//  Flip
//
//  Created by Fenimore, Michael on 7/12/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface LittleView2 : UIView {

}

@end
